package com.example.instax_maulana

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
