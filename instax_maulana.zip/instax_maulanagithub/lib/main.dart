// Digunakan Untuk Management proses Aplikasi
// Mengambil Package dari file home.dart

import 'package:flutter/material.dart';
import 'package:instax_maulana/home.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: DashBoard(),
  ));
}
