// Halaman awal Aplikasi

import 'package:flutter/material.dart';
import 'package:instax_maulana/class.dart';
import 'package:flutter/painting.dart';

class DashBoard extends StatefulWidget {
  @override
  _DashBoardState createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            IconButton(
              icon: Image.asset("foto/menu.png"),
              onPressed: () {},
            ),
            Container(
              width: 130,
              height: 130,
              child: IconButton(
                icon: Image.asset("foto/fujifilbanner.png"),
                onPressed: () {},
              ),
            ),
            IconButton(
              icon: Image.asset("foto/shop.png"),
              onPressed: () {},
            ),
          ],
        ),
      ),
      body: getBody(),
    );
  }

  Widget getBody() {
    return ListView(
      children: <Widget>[
        Padding(
          padding: EdgeInsets.only(top: 30, right: 25, left: 25, bottom: 25),
          child: Container(
            decoration: BoxDecoration(
                color: Colors.black, borderRadius: BorderRadius.circular(30)),
            child: TextField(
              style: TextStyle(color: Colors.white),
              cursorColor: Colors.white,
              decoration: InputDecoration(
                  border: InputBorder.none,
                  errorBorder: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  contentPadding: EdgeInsets.all(15),
                  hintText: 'Search',
                  hintStyle: TextStyle(color: Colors.white)),
            ),
          ),
        ),
        listInstax(
          tag: "Limited Edition",
          nama: "Instax",
          name: "Mini Mint 7+",
          price: "\$ 49.90",
          war: Color(0xff70b1a1),
          img: "InstaxMiniplus_1.png",
        ),
        listInstax(
          tag: "Limited Edition",
          nama: "Instax",
          name: "Mini Blue 7+",
          price: "\$ 50.90",
          war: Color(0xff77a0c6),
          img: "InstaxMini7plus_2.png",
        ),
        listInstax(
          tag: "Limited Edition",
          nama: "Instax",
          name: "Mini Coral 7+",
          price: "\$ 51.90",
          war: Color(0xffb0463c),
          img: "InstaxMini7plus_3.png",
        ),
        listInstax(
          tag: "Limited Edition",
          nama: "Instax",
          name: "Mini Pink 7+",
          price: "\$ 52.90",
          war: Color(0xffcf9496),
          img: "InstaxMini7plus_4.png",
        ),
        listInstax(
          tag: "Limited Edition",
          nama: "Instax",
          name: "Mini Lavender 7+",
          price: "\$ 53.90",
          war: Color(0xff855f8c),
          img: "InstaxMini7plus_5.png",
        ),
      ],
    );
  }
}

class listInstax extends StatelessWidget {
  listInstax({
    required this.tag,
    required this.nama,
    required this.name,
    required this.price,
    required this.img,
    required this.war,
  });

  final String tag;
  final String nama;
  final String name;
  final String price;
  final String img;
  final war;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 20, right: 20, left: 20),
      padding: EdgeInsets.only(top: 15, left: 10, bottom: 15),
      decoration:
          BoxDecoration(color: war, borderRadius: BorderRadius.circular(30)),
      child: Center(
        child: Row(
          children: <Widget>[
            Container(
              width: 150,
              margin: EdgeInsets.only(right: 100),
              child: Column(
                children: <Widget>[
                  Text(
                    tag,
                    style: TextStyle(fontSize: 10.0, color: Colors.white),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20, bottom: 20),
                    child: Row(
                      children: <Widget>[
                        Text(
                          nama,
                          style: TextStyle(
                              fontWeight: FontWeight.normal,
                              color: Colors.white),
                        ),
                        Text(
                          name,
                          style: TextStyle(
                              fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    price,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20.0,
                        color: Colors.white),
                  ),
                  RaisedButton(
                      shape: StadiumBorder(),
                      child: Text(
                        "BUY",
                        style:
                            TextStyle(fontWeight: FontWeight.bold, color: war),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Deskripsi(
                                  tag: tag,
                                  name: name,
                                  price: price,
                                  img: img,
                                  war: war)),
                        );
                      })
                ],
              ),
            ),

            // Eror saat memunculkan gambar
            // Seharusnya Gambar muncul, tetapi entah apa masalahnya

            Container(
              margin: EdgeInsets.only(left: 50),
              child: Image.asset(
                img,
                width: 120.0,
                height: 120.0,
              ),
            )
          ],
        ),
      ),
    );
  }
}
