// Detail Product Instax

import 'package:flutter/material.dart';
import 'package:instax_maulana/home.dart';

class Deskripsi extends StatelessWidget {
  Deskripsi({
    required this.tag,
    required this.name,
    required this.price,
    required this.img,
    required this.war,
  });
  final String tag;
  final String name;
  final String price;
  final String img;
  final war;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Color(0xffffffff),
        title: Image.asset(
          "foto/fujifilbanner.png",
          width: 150.0,
          height: 70.0,
        ),
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios,
            color: war,
          ),
          onPressed: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => DashBoard()));
          },
        ),
        actions: <Widget>[
          PopupMenuButton<String>(
              icon: Icon(
                Icons.more,
                color: Colors.black,
              ),
              onSelected: handleClick,
              itemBuilder: (BuildContext context) {
                return {'About', 'Settings'}.map((String chioce) {
                  return PopupMenuItem(value: chioce, child: Text(chioce));
                }).toList();
              })
        ],
      ),
      body: ListView(
        padding: EdgeInsets.only(top: 15, right: 20, left: 20, bottom: 30),
        children: <Widget>[
          Container(
            child: Column(
              children: <Widget>[
                Image.asset(
                  img,
                  width: 300,
                  height: 300,
                )
              ],
            ),
          ),
          Container(
            child: Row(
              children: [
                Text(
                  "Instax ",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25.0),
                ),
                Text(
                  name,
                  style: TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 25.0, color: war),
                )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
                "Be real and fun with the INSTAX MINI 7+. Cool design, colorful and compact, this instant camera is fun and easy to use. Point and shoot and give your day some fun!"),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
              "Point & Shoot",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
                "The Mini 7+ is easy to use! Simply point and shoot! With its exposure control adjustment and 60mm fixed-focus lens, the Mini 7+ makes it easy for you to be creative and live in the moment."),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
              "Mini But With Full-Size Memories",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
                "Pop it in your wallet, stick it to your wall – the INSTAX Mini film brings you instant 2 x 3 sized photos youcan show and tell."),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
                "Using professional high-quality film technology (as you’d expect from Fujifilm), your festival frolicking, sun worshipping, crowd surfing memories that you print will transport you right back into that moment."),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
              "Mini Film",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
                "Mini moments with maximum impact. What’s your next mini moment?"),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
              "Plenty of Great Color Choices",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
                "Available in five awesome colors: Lavender, Seafoam Green, Coral, Light Pink & Light Blue"),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
              "The Mini 7+ Has Your Back!",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
                "Depending upon the weather conditions, you can easily control brightness to obtain a great picture"),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
              "Fun All The Time!",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: Text(
                "Live in the moment and enjoy your Mini 7+, and give your day some instant fun!"),
          ),
        ],
      ),
      persistentFooterButtons: <Widget>[
        Container(
            margin: EdgeInsets.only(left: 10),
            child: Text(
              price,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
            )),
        RaisedButton(
            shape: StadiumBorder(),
            child: Text(
              "Buy Now",
              style: TextStyle(fontWeight: FontWeight.bold, color: war),
            ),
            onPressed: () {})
      ],
    );
  }
}

void handleClick(String value) {
  switch (value) {
    case 'About':
      break;
    case 'Settings':
      break;
  }
}
